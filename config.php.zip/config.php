<?php
$apiToken = "7483448997:AAEq7nkJF_HCjhBUtPWajIcf3afTBq4FLck";
// $channelid = "";